package com.example.fehling.flight_manager;

import java.io.Serializable;


public class Order implements Serializable {
    private int _id;
    private String name;
    private String starting;
    private String ending;
    private String insurance;
    private String idnum;
    private int flight_id ;
    private String Class ;

    public Order() {
    }

    public Order(int _id, String name, String starting, String ending, String insurance, String idnum , int flight_id , String Class) {
        this._id = _id;
        this.name = name ;
        this.starting = starting;
        this.ending = ending;
        this.insurance = insurance;
        this.idnum = idnum;
        this.flight_id = flight_id ;
        this.Class = Class ;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getname() {
        return name;
    }

    public void setname(String name) {
        this.name = name;
    }

    public String getStarting() {
        return starting;
    }

    public void setStarting(String starting) {
        this.starting = starting;
    }

    public String getEnding() {
        return ending;
    }

    public void setEnding(String ending) {
        this.ending = ending;
    }

    public String getinsurance() {
        return insurance;
    }

    public void setInsurance(String insurance) {
        this.insurance = insurance;
    }

    public String getIdnum() {
        return idnum;
    }

    public void setIdnum(String idnum) {
        this.idnum = idnum;
    }

    public int getFlight_id(){return flight_id ;}

    public void setFlight_id(int flight_id) {this.flight_id = flight_id ;}

    public String getClass1(){
        return Class ;
    }

    public void setClass1(){
        this.Class = Class ;
    }
}

