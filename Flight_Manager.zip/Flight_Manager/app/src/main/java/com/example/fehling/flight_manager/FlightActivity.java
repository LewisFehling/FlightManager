package com.example.fehling.flight_manager;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.fehling.flight_manager.R ;

import static android.provider.ContactsContract.*;

class FlightActivity extends AppCompatActivity {

    private EditText mTilflightID;
    private EditText mTilCompany;
    private EditText mTilStarting;
    private EditText mTilEnding;
    private EditText mTilTime;
    private EditText mTilPrice;
    private EditText mTilSeatnum;
    private Button mBtnSubmit;


    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flight);
        mTilflightID = (EditText)findViewById(R.id.id_til_add_flightID);
        mTilCompany = (EditText)findViewById(R.id.id_til_add_company);
        mTilStarting = (EditText)findViewById(R.id.id_til_add_starting);
        mTilEnding = (EditText)findViewById(R.id.id_til_add_ending);
        mTilTime = (EditText)findViewById(R.id.id_til_add_time);
        mTilPrice = (EditText) findViewById(R.id.id_til_add_price);
        mTilSeatnum = (EditText)findViewById(R.id.id_til_add_seatnum);
        mBtnSubmit = (Button)findViewById(R.id.id_btn_flight_submit);

        mTilflightID.setHint("航班号");
        mTilCompany.setHint("航空公司");
        mTilStarting.setHint("起点");
        mTilEnding.setHint("终点");
        mTilTime.setHint("时间");
        mTilPrice.setHint("价格");
        mTilSeatnum.setHint("座位数");
        mBtnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FlightDAO flightDAO = new FlightDAO(FlightActivity.this, "test1_db", null, 1);
                int seatnum = 0;
                String flightid = mTilflightID.getText().toString();
                String company = mTilCompany.getText().toString();
                String starting = mTilStarting.getText().toString();
                String ending = mTilEnding.getText().toString();
                String price = mTilPrice.getText().toString();
                String flightTime = mTilTime.getText().toString();
                String indexseatnum = String.valueOf(mTilSeatnum.getText());
                seatnum = Integer.parseInt(indexseatnum);
                if (!TextUtils.isEmpty(company)
                        && !TextUtils.isEmpty(starting)
                        && !TextUtils.isEmpty(ending)
                        && !TextUtils.isEmpty(price)
                        && !TextUtils.isEmpty(flightTime)
                        && seatnum != 0) {
                    SQLiteDatabase db = flightDAO.getWritableDatabase();
                    int row = flightDAO.insert(db, flightid, company, starting, ending, price, flightTime, seatnum);
                    db.close();
                    System.out.println("jjjjjjjjjjjjjjjjjjjjjjjjj " + row );
                    if (row > 0) {
                        //Log.e(getString(row), "onClick: 添加成功 ");
                        Toast.makeText(getApplicationContext(), "添加成功", Toast.LENGTH_SHORT).show();
                    }
                    Intent intent = new Intent(FlightActivity.this, Root_select_menu.class);
                    startActivity(intent);
                    SQLiteDatabase db1 = flightDAO.getWritableDatabase() ;
                    Cursor cursor = db1.rawQuery("select * from flights", null) ;
                    while(cursor.moveToNext()){
                        String id = cursor.getString(cursor.getColumnIndex("flight_id"));
                        String name = cursor.getString(cursor.getColumnIndex("flight_company"));
                        String age = cursor.getString(cursor.getColumnIndex("flight_price"));
                        //Toast.makeText(FlightActivity.this, "_id="+id+" name="+name+"  age="+age, 1000).show();
                    }
                    finish();
                }
            }
        });
    }
}

