package com.example.fehling.flight_manager;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Root_login_Activity extends AppCompatActivity{
    private EditText Root_password ;
    private Button Root_submit ;

    protected void onCreate (@Nullable Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_root_login);

        Root_password = (EditText)findViewById(R.id.id_root_login_password) ;
        Root_submit = (Button)findViewById(R.id.id_root_login_submit) ;

        Root_password.setHint("请输入管理员密码");

        Root_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String root_password = Root_password.getText().toString() ;
                if(root_password.equals("abc123")){
                    Toast.makeText(getApplicationContext(), "登陆成功", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Root_login_Activity.this , Root_select_menu.class) ;
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}
