package com.example.fehling.flight_manager;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class Guest_activity extends AppCompatActivity implements View.OnClickListener {

    private Button Guset_show_all ;
    private Button Guest_search ;

    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest);

        Guset_show_all = (Button)findViewById(R.id.id_guest_show_all_flight) ;
        Guest_search = (Button)findViewById(R.id.id_guest_search) ;

        Guset_show_all.setOnClickListener(this);
        Guest_search.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.id_guest_show_all_flight:
                Intent intent = new Intent(this, Root_show_all_flight_Activity.class);
                startActivity(intent);
                break;

            case R.id.id_guest_search:
                Intent intent1 = new Intent(this, Guest_search_Activity.class);
                startActivity(intent1);
                break;
        }
    }
}
