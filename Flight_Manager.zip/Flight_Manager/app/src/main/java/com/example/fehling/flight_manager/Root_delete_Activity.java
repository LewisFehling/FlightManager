package com.example.fehling.flight_manager;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

class Root_delete_Activity extends AppCompatActivity{

    private EditText Root_delete_text ;
    private Button Root_delete_submit ;

    protected void onCreate(@Nullable Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_root_delete);

        Root_delete_text = (EditText)findViewById(R.id.id_root_delete_text) ;
        Root_delete_submit = (Button) findViewById(R.id.id_root_delete_submit) ;

        Root_delete_text.setHint("请输入需要删除的航班号");

        Root_delete_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FlightDAO flightDAO = new FlightDAO(Root_delete_Activity.this,"test1_db",null,1);
                SQLiteDatabase db = flightDAO.getWritableDatabase();
                String root_delete_text = Root_delete_text.getText().toString() ;
                flightDAO.delete(db,root_delete_text) ;
                db.close();
                Intent intent = new Intent(Root_delete_Activity.this,Root_select_menu.class) ;
                startActivity(intent);
                finish();
            }
        });
    }
}
