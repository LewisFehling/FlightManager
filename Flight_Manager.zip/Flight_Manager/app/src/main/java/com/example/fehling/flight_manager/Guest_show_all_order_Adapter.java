package com.example.fehling.flight_manager;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class Guest_show_all_order_Adapter extends ArrayAdapter {
    private  int resourceId;
    public Guest_show_all_order_Adapter(@NonNull Context context, int resource, List<Order> object) {
        super(context, resource,object);
        resourceId = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Order order = (Order) getItem(position);
        View view;
        if(convertView == null){
            view =  LayoutInflater.from(getContext()).inflate(resourceId,null);
        }else{
            view = convertView;
        }
        TextView order_id = (TextView)view.findViewById(R.id.id_order_id_show);
        TextView order_name = (TextView)view.findViewById(R.id.id_order_name_show);
        TextView order_idnum = (TextView)view.findViewById(R.id.id_order_idnum_show);
        TextView order_flight_id = (TextView)view.findViewById(R.id.id_order_flight_id_show);
        TextView order_start = (TextView)view.findViewById(R.id.id_order_start_show);
        TextView order_end = (TextView)view.findViewById(R.id.id_order_end_show);
        TextView order_class = (TextView)view.findViewById(R.id.id_order_class_show);
        TextView order_insruance = (TextView)view.findViewById(R.id.id_order_insurance_show) ;
        order_id.setText(Integer.toString(order.get_id()));
        order_name.setText(order.getname());
        order_idnum.setText(order.getIdnum());
        order_flight_id.setText(Integer.toString(order.getFlight_id()));
        order_start.setText(order.getStarting());
        order_end.setText(order.getEnding());
        order_class.setText(order.getClass1());
        order_insruance.setText(order.getinsurance());
        return view;
    }
}
