package com.example.fehling.flight_manager;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.fehling.flight_manager.R;

import java.util.List;

/**
 * Created by wuchaochao on 2018/9/4.
 */

public class Root_show_all_flight_Adapter extends ArrayAdapter {
    private  int resourceId;
    public Root_show_all_flight_Adapter(@NonNull Context context, int resource, List<Flight> object) {
        super(context, resource,object);
        resourceId = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Flight flight = (Flight) getItem(position);
        View view;
        if(convertView == null){
            view =  LayoutInflater.from(getContext()).inflate(resourceId,null);
        }else{
            view = convertView;
        }
        TextView  flight_id = (TextView)view.findViewById(R.id.id_item_flight_id_show);
        TextView  flight_price = (TextView)view.findViewById(R.id.id_item_flight_price_show);
        TextView  flight_start = (TextView)view.findViewById(R.id.id_item_flight_start_show);
        TextView  flight_end = (TextView)view.findViewById(R.id.id_item_flight_end_show);
        TextView  flight_time = (TextView)view.findViewById(R.id.id_item_flight_time_show);
        TextView  flight_seatnum = (TextView)view.findViewById(R.id.id_item_flight_seatnum_show);
        TextView  flight_company = (TextView)view.findViewById(R.id.id_item_flight_company_show);
        flight_id.setText(Integer.toString(flight.get_id()));
        flight_price.setText(flight.getPrize());
        flight_start.setText(flight.getStarting());
        flight_end.setText(flight.getEnding());
        flight_time.setText(flight.getFlightTime());
        flight_seatnum.setText(Integer.toString(flight.getSeatnum()));
        flight_company.setText(flight.getCompany());
        return view;
    }
}
