package com.example.fehling.flight_manager;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Guest_show_all_order_Activity extends AppCompatActivity {

    private List<Order> orders_list = new ArrayList<>();
    Toolbar mToolbar;
    ListView listView;
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_root_show_all_order);
        //mToolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(mToolbar);
        Init();
        final Guest_show_all_order_Adapter guest_show_all_order_adapter = new Guest_show_all_order_Adapter(Guest_show_all_order_Activity.this,R.layout.item_activity_root_show_all_order,orders_list);
        listView = (ListView)findViewById(R.id.list_order_display);
        listView.setAdapter(guest_show_all_order_adapter);
    }

    private void  Init(){
        FlightDAO flightDAO = new FlightDAO(Guest_show_all_order_Activity.this,"test1_db",null,1);
        SQLiteDatabase db = flightDAO.getWritableDatabase();
        orders_list = flightDAO.select_all_order(db);
        db.close();
    }
}
