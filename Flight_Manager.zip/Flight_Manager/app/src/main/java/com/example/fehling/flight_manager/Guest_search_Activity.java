package com.example.fehling.flight_manager;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

class Guest_search_Activity extends AppCompatActivity {

    private List<Flight> flight_list = new ArrayList<>();
    private EditText Guest_search_start ;
    private EditText Guest_search_end ;
    private Button Guest_search_submit ;
    private ListView listView ;


    protected void onCreate(@Nullable Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest_search);

        Guest_search_start = (EditText)findViewById(R.id.id_guest_search_start);
        Guest_search_end = (EditText)findViewById(R.id.id_guest_search_end) ;
        Guest_search_submit = (Button)findViewById(R.id.id_guest_search_submit) ;

        Guest_search_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                init();
                Root_show_all_flight_Adapter root_show_all_flight_adapter = new Root_show_all_flight_Adapter(Guest_search_Activity.this, R.layout.item_activity_root_show_all_flight, flight_list);
                listView = (ListView) findViewById(R.id.id_guest_search_display);
                listView.setAdapter(root_show_all_flight_adapter);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Flight flight = flight_list.get(position) ;
                        Intent intent = new Intent(Guest_search_Activity.this,Guest_info_input_Activity.class);
                        //System.out.println("flight_id               "+flight.get_id());

                        //传参给下个活动
                        Flight indexflight = new Flight(flight.get_id(), flight.getCompany(), flight.getStarting(),
                                                        flight.getEnding(),flight.getPrize(),flight.getFlightTime(),
                                                        flight.getSeatnum()) ;
                        intent.putExtra("flight",indexflight) ;
                        startActivity(intent);
                    }
                });
            }
        });

    }

    private void init(){
        FlightDAO flightDAO = new FlightDAO(Guest_search_Activity.this,"test1_db",null,1);
        SQLiteDatabase db = flightDAO.getWritableDatabase();
        String start = Guest_search_start.getText().toString() ;
        String end = Guest_search_end.getText().toString() ;
        flight_list = flightDAO.search(db,start ,end) ;
        db.close();
    }
}
