package com.example.fehling.flight_manager;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

class Root_show_all_flight_Activity extends AppCompatActivity{

    private List<Flight> flight_list = new ArrayList<>();
    Toolbar mToolbar;
    ListView listView;
    FlightDAO flightDAO;
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_root_show_all_flight);
        //mToolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(mToolbar);
        Init();
        final Root_show_all_flight_Adapter root_show_all_flight_adapter = new Root_show_all_flight_Adapter(Root_show_all_flight_Activity.this,R.layout.item_activity_root_show_all_flight,flight_list);
        listView = (ListView)findViewById(R.id.list_display);
        listView.setAdapter(root_show_all_flight_adapter);
    }

    private void  Init(){
        FlightDAO flightDAO = new FlightDAO(Root_show_all_flight_Activity.this,"test1_db",null,1);
        SQLiteDatabase db = flightDAO.getWritableDatabase();
        flight_list = flightDAO.select_all(db);
        db.close();
    }
}
