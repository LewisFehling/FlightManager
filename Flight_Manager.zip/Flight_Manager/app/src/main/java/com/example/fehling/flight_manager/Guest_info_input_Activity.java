package com.example.fehling.flight_manager;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class Guest_info_input_Activity extends AppCompatActivity{

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest_info_input);

        //上一个活动的参数
        Intent intent = getIntent() ;
        final Flight flight = (Flight) intent.getSerializableExtra("flight") ;
        System.out.println(flight.get_id()+"     "+flight.getCompany()+"    " + flight.getSeatnum());

        final int flight_id = flight.get_id() ;
        final String start = flight.getStarting() ;
        final String ending = flight.getEnding() ;

        final TextView Guest_info_name = (TextView)findViewById(R.id.id_guest_info_name) ;
        final TextView Guest_info_idnum = (TextView)findViewById(R.id.id_guest_info_idnum) ;
        Button Guest_info_submit = (Button)findViewById(R.id.id_guest_info_submit) ;
        Spinner Guest_info_class = (Spinner)findViewById(R.id.id_guest_info_select_class);
        Spinner Guest_info_insurance = (Spinner)findViewById(R.id.id_guest_info_select_insuranc);


        final String[] guest_info_class = new String[1];
        final String[] guest_info_insurance = new String[1];

        Guest_info_class.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String[] Class = getResources().getStringArray(R.array.class1);
                guest_info_class[0] = Class[position] ;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Guest_info_insurance.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String[] insurance = getResources().getStringArray(R.array.insurance1) ;
                guest_info_insurance[0] = insurance[position] ;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Guest_info_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FlightDAO flightDAO = new FlightDAO(Guest_info_input_Activity.this, "test1_db", null, 1);
                int order_id = Random1() ;
                String name = Guest_info_name.getText().toString() ;
                String idnum = Guest_info_idnum.getText().toString() ;
                String Class = guest_info_class[0] ;
                String insurance = guest_info_insurance[0] ;

                System.out.println("order_id " + order_id + "  name  " + name +
                                    "  idnum  " + idnum + "   flight_id   " + flight_id +
                                    "   start   " + start + "   ending   " + ending +
                                    "  Class  " + Class + "  insurance   " + insurance) ;

                SQLiteDatabase db = flightDAO.getWritableDatabase();
                int row = flightDAO.order_insert(db,order_id, name,idnum,flight_id , start ,ending  ,Class,insurance);
                flightDAO.updatenum(db,flight.getSeatnum(),flight_id);
                db.close();
                System.out.println("rowwwwwwwwwwwwwwwwwwwwwww    " + row) ;
                if(row > 0){
                    Toast.makeText(getApplicationContext(), "购买成功", Toast.LENGTH_SHORT).show();
                }
                Intent intent = new Intent(Guest_info_input_Activity.this, Guest_search_Activity.class);
                startActivity(intent);
                finish();
            }
        });

    }

    private int Random1() {
        Random ran = new Random();
        if(ran.nextInt()>0){
            return ran.nextInt() ;
        }
        else {
            return -ran.nextInt();
        }
    }
}
