package com.example.fehling.flight_manager;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import java.io.BufferedOutputStream;

public class Root_select_menu extends AppCompatActivity implements View.OnClickListener {

    private Button Root_add ;
    private Button Root_delete ;
    private Button Root_update ;
    private Button Root_show ;
    private Button Root_show_order ;
    private Button Root_delete_table ;

    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_menu);

        Root_add = (Button)findViewById(R.id.id_root_add) ;
        Root_delete = (Button)findViewById(R.id.id_root_delete) ;
        Root_update = (Button)findViewById(R.id.id_root_update) ;
        Root_show = (Button)findViewById(R.id.id_root_show_all_flight) ;
        Root_show_order = (Button)findViewById(R.id.id_root_show_all_order) ;
        Root_delete_table = (Button)findViewById(R.id.id_root_delete_table) ;

        Root_add.setOnClickListener(this);
        Root_delete.setOnClickListener(this);
        Root_update.setOnClickListener(this);
        Root_show.setOnClickListener(this);
        Root_show_order.setOnClickListener(this);
        Root_delete_table.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.id_root_add :
                Intent intent = new Intent(this , FlightActivity.class) ;
                startActivity(intent);
                break;

            case R.id.id_root_delete:
                Intent intent1 = new Intent(this , Root_delete_Activity.class) ;
                startActivity(intent1);
                break;

            case R.id.id_root_update:
                Intent intent2 = new Intent(this , Root_update_Activity.class) ;
                startActivity(intent2);
                break;

            case R.id.id_root_show_all_flight:
                Intent intent3 = new Intent(this , Root_show_all_flight_Activity.class);
                startActivity(intent3);
                break;

            case R.id.id_root_show_all_order:
                Intent intent4 = new Intent(this,Guest_show_all_order_Activity.class);
                startActivity(intent4);
                break;

            case R.id.id_root_delete_table:
                Intent intent5 = new Intent(this,MainActivity.class);
                startActivity(intent5);
                finish();
                break;
        }
    }
}
