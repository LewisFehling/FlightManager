package com.example.fehling.flight_manager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class FlightDAO extends SQLiteOpenHelper {

    private FlightDAO flightDAO ;

    public FlightDAO(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table flights("+
                "flight_id INTEGER PRIMARY KEY NOT NULL,"+
                "flight_company TEXT NOT NULL," +
                "flight_start TEXT NOT NULL," +
                "flight_end TEXT NOT NULL," +
                "flight_time TEXT NOT NULL," +
                "flight_price INTEGER NOT NULL," +
                "flight_seatnum INTEGER NOT NULL)");

        db.execSQL("create table guest("+
                "guest_name TEXT PRIMARY KEY UNIQUE NOT NULL,"+
                "guest_pwd TEXT NOT NULL)");

        db.execSQL("create table ticket("+
                "_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                "flight_id INTEGER REFERENCES flights(flight_id) NOT NULL," +
                "seat_id INTEGER UNIQUE NOT NULL," +
                "seat_info TEXT NOT NULL," +
                "is_pick Boolean NOT NULL)");

        db.execSQL("create table orders("+
                "order_id11 INTEGER PRIMARY KEY NOT NULL, "+
                "guest_name11 TEXT  NOT NULL," +
                "guest_ID11 TEXT NOT NULL ," +
                "flight_id11 INTEGER NOT NULL," +
                "start11 TEXT NOT NULL," +
                "flight_ending11 TEXT NOT NULL,"+
                "class11 TEXT NOT NULL ,"+
                "flight_insurance11 TEXT NOT NULL)");
    }

    public int insert(SQLiteDatabase db,String flightid , String company , String start , String end , String price , String time , int seatnum ){
        db.beginTransaction();
        Log.e(flightid, "insert: success" );
        ContentValues contentValues = new ContentValues();
        contentValues.put("flight_id", flightid );
        contentValues.put("flight_company" , company);
        contentValues.put("flight_start" , start);
        contentValues.put("flight_end" , end) ;
        contentValues.put("flight_price" , price);
        contentValues.put("flight_time" , time);
        contentValues.put("flight_seatnum" , seatnum);
        int row = 0 ;
        try {
            row = (int) db.insert("flights",null ,contentValues);
        }catch (Exception e){
            e.printStackTrace();
        }
        db.setTransactionSuccessful();
        db.endTransaction();
        return row ;
    }

    public  int order_insert(SQLiteDatabase db,int order_id , String name , String guest_idnum , int flight_id ,String start , String ending ,String Class , String insurance){
        db.beginTransaction();
        ContentValues contentValues = new ContentValues() ;
        contentValues.put("order_id11",order_id);
        contentValues.put("guest_name11",name);
        contentValues.put("guest_ID11",guest_idnum);
        contentValues.put("flight_id11",flight_id);
        contentValues.put("start11",start);
        contentValues.put("flight_ending11",ending);
        contentValues.put("class11",Class);
        contentValues.put("flight_insurance11",insurance);
        int row = 0 ;
        try{
            row = (int)db.insert("orders" , null ,contentValues);
        }catch (Exception e){
            e.printStackTrace();
        }
        db.setTransactionSuccessful();
        db.endTransaction();
        return row ;
    }

    public void delete(SQLiteDatabase db , String _id){
        String a = "success" ;
        try{
            db.execSQL("delete from flights where flight_id=?",new String []{_id});
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public List select_all_order(SQLiteDatabase db){
        String sql = "select * from orders";
        List<Order> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql,null);
        while (cursor.moveToNext()){
            Order orders = new Order(cursor.getInt(cursor.getColumnIndex("order_id11")),
                    cursor.getString(cursor.getColumnIndex("guest_name11")),
                    cursor.getString(cursor.getColumnIndex("start11")),
                    cursor.getString(cursor.getColumnIndex("flight_ending11")),
                    cursor.getString(cursor.getColumnIndex("flight_insurance11")),
                    cursor.getString(cursor.getColumnIndex("guest_ID11")),
                    cursor.getInt(cursor.getColumnIndex("flight_id11")),
                    cursor.getString(cursor.getColumnIndex("class11")));
            Log.e("dskfsjadkfjsasdfkj",cursor.getString(0));
            list.add(orders);
        }
        db.close();
        return  list;
    }

    public List select_all(SQLiteDatabase db){
        String sql = "select * from flights";
        List<Flight> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql,null);
        while (cursor.moveToNext()){
            Flight flight = new Flight(cursor.getInt(cursor.getColumnIndex("flight_id")),
                    cursor.getString(cursor.getColumnIndex("flight_company")),
                    cursor.getString(cursor.getColumnIndex("flight_start")),
                    cursor.getString(cursor.getColumnIndex("flight_end")),
                    cursor.getString(cursor.getColumnIndex("flight_time")),
                    cursor.getString(cursor.getColumnIndex("flight_price")),
                    cursor.getInt(cursor.getColumnIndex("flight_seatnum")));
            Log.e("dskfsjadkfjsasdfkj",cursor.getString(0));
            list.add(flight);
        }
        db.close();
        return  list;
    }

    public List search (SQLiteDatabase db , String start1 , String end1){
        String sql = "select * from flights where flight_start=? and flight_end=?";
        List<Flight> list = new ArrayList<>() ;
        Cursor cursor = db.rawQuery(sql, new String[] {start1,end1} , null) ;
        while (cursor.moveToNext()){
            Flight flight = new Flight(cursor.getInt(cursor.getColumnIndex("flight_id")),
                    cursor.getString(cursor.getColumnIndex("flight_company")),
                    cursor.getString(cursor.getColumnIndex("flight_start")),
                    cursor.getString(cursor.getColumnIndex("flight_end")),
                    cursor.getString(cursor.getColumnIndex("flight_time")),
                    cursor.getString(cursor.getColumnIndex("flight_price")),
                    cursor.getInt(cursor.getColumnIndex("flight_seatnum")));
            Log.e("search success" , cursor.getString(0)) ;
            list.add(flight) ;
        }
        db.close();
        return list ;
    }

    public void updatenum(SQLiteDatabase db , int seatnum , int _id){
        db.execSQL("update flights set flight_seatnum = flight_seatnum-1 where flight_id=" + _id);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
